let openMap = () => {
    window.location.assign("https://maps.app.goo.gl/NZfcYeRsZp6fPE3WA")
}